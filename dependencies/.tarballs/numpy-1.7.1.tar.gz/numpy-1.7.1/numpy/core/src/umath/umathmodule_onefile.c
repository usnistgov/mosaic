#include "loops.c"

#include "ufunc_object.c"
#include "ufunc_type_resolution.c"
#include "reduction.c"
#include "umathmodule.c"
