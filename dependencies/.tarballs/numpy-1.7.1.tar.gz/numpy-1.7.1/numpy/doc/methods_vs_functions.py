"""

=====================
Methods vs. Functions
=====================

Placeholder for Methods vs. Functions documentation.

"""
