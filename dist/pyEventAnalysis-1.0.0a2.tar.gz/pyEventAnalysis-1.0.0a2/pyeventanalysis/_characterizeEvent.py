import numpy as np
import util

class InvalidEvent(Exception):
	pass


def levelchange(dat, sMean, sSD, nSD, blksz):
	for i in range(int(blksz/2.0), len(dat)-int(blksz/2.0)):
		if abs(util.avg(dat[i-int(blksz/2.0):i+int(blksz/2.0)])-sMean) > nSD * sSD:
			return  [i+1, util.avg(dat[i:i+blksz])]

	raise InvalidEvent()

def characterizeevent(dat, mean, sd, nSD, blksz):
	tdat=dat #movingaverage(dat, 2*blksz)
	tt=[0, mean]
	mu=[0]
	a=[mean]
	t1=0
	while (1):
		tt=levelchange( tdat[t1:], tt[1], sd, nSD, blksz )
		t1+=tt[0]
		mu.append(t1)
		a.append(tt[1])
		if abs(tt[1]) > (mean-nSD*sd):
			break

	return zip(a,mu)