
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.12.0'
version = '0.12.0'
full_version = '0.12.0'
git_revision = 'cdd6b32233bbecc3e8cbc82531905b74f3ea66eb'
release = True

if not release:
    version = full_version
